How to Use

Option 1: Browse map

1. Click OSM → Browse OpenStreetMap to open a map
2. Navigate to your location
3. Click the square button and draw a rectangle around the area you want to import
4. Click Load to DesignBuilder

Option 2: Import file

1. Click OSM → OpenStreetMap website to open www.openstreetmap.org
2. Navigate to your location
3. Click Export at the top
4. Draw a rectangle around the area you want to import
5. Click the blue Export button to download the .osm file
6. Click OSM → Load OpenStreetMap file
7. Select your downloaded .osm file